"""
data_history_report.py
──────────────────────
Scan the entire chain (block 0 → latest) and produce a clean text-table
report of reward activity.

Aggregated stats:
  • Total redemptions per reward item (sorted by popularity)
  • Total registrations
  • Total coin-mint events
  • Total coin transfers

All counts are stored in Python dicts before printing.

Run:
    python system/data_history_report.py
"""

import sys
from pathlib import Path

from web3.logs import DISCARD

sys.path.append(str(Path(__file__).resolve().parents[1] / "admin"))

from admin_helpers import connect, format_token, get_contract, load_deployments


def get_item_name(store, item_id):
    """Safely fetch a reward item's name by id."""
    try:
        return store.functions.getRewardItem(item_id).call()[0]
    except Exception:
        return "Unknown Item"


def print_aligned_table(title, headers, rows, col_widths):
    """
    Print a title, header row, separator, and data rows with aligned columns.
    col_widths is a list of ints matching the length of headers.
    """
    print()
    print(title)
    print("=" * (sum(col_widths) + len(col_widths) * 2 - 1))

    # Header
    header_line = "  ".join(
        str(h).ljust(col_widths[i]) for i, h in enumerate(headers)
    )
    print(header_line)

    # Separator
    sep_line = "  ".join("-" * col_widths[i] for i in range(len(headers)))
    print(sep_line)

    # Data rows
    if not rows:
        print("(no data)")
        return

    for row in rows:
        line = "  ".join(
            str(row[i]).ljust(col_widths[i]) for i in range(len(headers))
        )
        print(line)


def main():
    w3 = connect()
    deployments = load_deployments()

    store = get_contract(w3, "StoreRewards",   deployments["StoreRewards"])
    coin  = get_contract(w3, "RewardPointCoin", deployments["RewardPointCoin"])

    # ── Counters (stored in dicts before output) ──────────────────────────────
    redemptions_per_item = {}   # item_id → count
    total_registrations  = 0
    total_mint_events    = 0
    total_transfers      = 0
    total_rpc_minted     = 0

    latest = w3.eth.block_number

    print(f"Scanning blocks 0 → {latest}…")

    for block_number in range(latest + 1):
        block = w3.eth.get_block(block_number, full_transactions=True)

        for tx in block.transactions:
            receipt = w3.eth.get_transaction_receipt(tx["hash"])

            # RewardRedeemed
            for event in store.events.RewardRedeemed().process_receipt(
                receipt, errors=DISCARD
            ):
                item_id = event["args"]["itemId"]
                redemptions_per_item[item_id] = (
                    redemptions_per_item.get(item_id, 0) + 1
                )

            # UserRegistered
            for _ in store.events.UserRegistered().process_receipt(
                receipt, errors=DISCARD
            ):
                total_registrations += 1

            # Transfer (coin)
            for event in coin.events.Transfer().process_receipt(
                receipt, errors=DISCARD
            ):
                zero = "0x0000000000000000000000000000000000000000"
                if event["args"]["from"] == zero:
                    total_mint_events += 1
                    total_rpc_minted  += event["args"]["value"]
                else:
                    total_transfers += 1

    # ── Print summary stats ───────────────────────────────────────────────────
    print()
    print("Data History Report – Store Rewards & Points")
    print("=" * 46)
    print(f"  Blocks scanned         : {latest + 1}")
    print(f"  Total registrations    : {total_registrations}")
    print(f"  Total mint events      : {total_mint_events}")
    print(f"  Total RPC minted       : {format_token(total_rpc_minted)} RPC")
    print(f"  Total coin transfers   : {total_transfers}")

    # ── Most popular reward items ─────────────────────────────────────────────
    sorted_items = sorted(
        redemptions_per_item.items(),
        key=lambda kv: kv[1],
        reverse=True,
    )

    rows = []
    for item_id, count in sorted_items:
        name = get_item_name(store, item_id)
        rows.append((item_id, name[:32], count))

    print_aligned_table(
        title="Most Popular Reward Items (by redemptions)",
        headers=["ID", "Reward Item Name", "Redemptions"],
        rows=rows,
        col_widths=[4, 34, 11],
    )

    if not rows:
        print("  (no redemptions recorded yet)")

    print()


if __name__ == "__main__":
    main()
