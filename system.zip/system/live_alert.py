"""
live_alert.py
─────────────
Poll new blocks and print an alert whenever a reward is redeemed or a
new user registers.

Algorithm:
  - Record the current block as `last_seen_block`.
  - Every 2 seconds check `w3.eth.block_number`.
  - If new blocks exist, scan each one for contract events.
  - Print a detailed alert line for every relevant event found.
  - Update `last_seen_block` to avoid re-scanning.

Run:
    python system/live_alert.py
"""

import sys
import time
from pathlib import Path

from web3.logs import DISCARD

sys.path.append(str(Path(__file__).resolve().parents[1] / "admin"))

from admin_helpers import connect, format_token, get_contract, load_deployments

POLL_INTERVAL = 2  # seconds between block checks


def main():
    w3 = connect()
    deployments = load_deployments()

    store = get_contract(w3, "StoreRewards",   deployments["StoreRewards"])
    coin  = get_contract(w3, "RewardPointCoin", deployments["RewardPointCoin"])

    # Start watching from the current head so we only catch NEW activity.
    last_seen_block = w3.eth.block_number

    print()
    print("Live Alert System – Store Rewards & Points")
    print("=" * 44)
    print(f"  Watching from block {last_seen_block}. Press Ctrl+C to stop.")
    print()

    try:
        while True:
            latest_block = w3.eth.block_number   # check current block number

            if latest_block > last_seen_block:
                # New blocks detected – scan each one.
                for block_number in range(last_seen_block + 1, latest_block + 1):
                    block = w3.eth.get_block(block_number, full_transactions=True)

                    for tx in block.transactions:
                        receipt = w3.eth.get_transaction_receipt(tx["hash"])

                        # ── RewardRedeemed events ──────────────────────────
                        for event in store.events.RewardRedeemed().process_receipt(
                            receipt, errors=DISCARD
                        ):
                            user      = event["args"]["user"]
                            item_name = event["args"]["itemName"]
                            cost      = event["args"]["cost"]
                            item_id   = event["args"]["itemId"]
                            print(
                                f"  [Block {block_number}] ALERT: Reward redeemed! "
                                f"User {user[:10]}…  item='{item_name}' (id {item_id})  "
                                f"cost={cost} RPC"
                            )

                        # ── UserRegistered events ──────────────────────────
                        for event in store.events.UserRegistered().process_receipt(
                            receipt, errors=DISCARD
                        ):
                            user = event["args"]["user"]
                            name = event["args"]["name"]
                            print(
                                f"  [Block {block_number}] ALERT: New user registered! "
                                f"'{name}'  ({user[:10]}…)"
                            )

                        # ── Transfer (mint) events from RewardPointCoin ────
                        for event in coin.events.Transfer().process_receipt(
                            receipt, errors=DISCARD
                        ):
                            from_addr = event["args"]["from"]
                            to_addr   = event["args"]["to"]
                            amount    = event["args"]["value"]
                            if from_addr == "0x0000000000000000000000000000000000000000":
                                print(
                                    f"  [Block {block_number}] ALERT: Coins minted! "
                                    f"{format_token(amount)} RPC → {to_addr[:10]}…"
                                )

                # Update the watermark so we don't re-process these blocks.
                last_seen_block = latest_block

            time.sleep(POLL_INTERVAL)

    except KeyboardInterrupt:
        print("\nAlert system stopped.")


if __name__ == "__main__":
    main()
