"""
balance_snapshot_exporter.py
─────────────────────────────
Scan the blockchain to discover every address that has appeared in any
transaction or Transfer event, then write a CSV snapshot of each
address's RPC coin balance and ETH balance.

Output:
    reports/balance_snapshot.csv

CSV format:
    Account Address, Reward Point Coin Balance, ETH Balance

Run:
    python system/balance_snapshot_exporter.py
"""

import csv
import sys
from pathlib import Path

from web3.logs import DISCARD

sys.path.append(str(Path(__file__).resolve().parents[1] / "admin"))

from admin_helpers import (
    ROOT_DIR,
    connect,
    format_eth,
    format_token,
    get_contract,
    load_deployments,
)

ZERO_ADDRESS = "0x0000000000000000000000000000000000000000"


def collect_seen_accounts(w3, coin, deployments):
    """
    Iterate every block from 0 to the current head and collect every
    address that has appeared in a transaction or Transfer event.
    Returns a sorted list of unique checksum addresses.
    """
    # Seed with known accounts so Ganache accounts always appear in the CSV.
    accounts = set(w3.eth.accounts)
    accounts.add(deployments["admin"])
    for user in deployments.get("sample_users", []):
        accounts.add(user)

    latest = w3.eth.block_number

    for block_number in range(latest + 1):
        block = w3.eth.get_block(block_number, full_transactions=True)

        for tx in block.transactions:
            accounts.add(tx["from"])
            if tx["to"]:
                accounts.add(tx["to"])

            receipt = w3.eth.get_transaction_receipt(tx["hash"])

            # Pull addresses out of every Transfer event so wallets that only
            # received tokens (and never sent a raw tx) are included.
            for event in coin.events.Transfer().process_receipt(
                receipt, errors=DISCARD
            ):
                from_addr = event["args"]["from"]
                to_addr   = event["args"]["to"]
                if from_addr != ZERO_ADDRESS:
                    accounts.add(from_addr)
                if to_addr   != ZERO_ADDRESS:
                    accounts.add(to_addr)

    # Remove the zero address; it is a mint sentinel, not a real account.
    accounts.discard(ZERO_ADDRESS)

    return sorted(accounts)


def main():
    w3 = connect()
    deployments = load_deployments()
    coin = get_contract(w3, "RewardPointCoin", deployments["RewardPointCoin"])

    print("Collecting accounts from blockchain…")
    accounts = collect_seen_accounts(w3, coin, deployments)
    print(f"Found {len(accounts)} unique addresses.")

    # ── Write CSV ─────────────────────────────────────────────────────────────
    output_dir  = ROOT_DIR / "reports"
    output_dir.mkdir(exist_ok=True)
    output_path = output_dir / "balance_snapshot.csv"

    with output_path.open("w", newline="") as csv_file:
        writer = csv.writer(csv_file)

        # Header row (required by the spec).
        writer.writerow(
            ["Account Address", "Reward Point Coin Balance", "ETH Balance"]
        )

        # One row per account using balanceOf and get_balance.
        for account in accounts:
            coin_balance = coin.functions.balanceOf(account).call()
            eth_balance  = w3.eth.get_balance(account)

            writer.writerow([
                account,
                format_token(coin_balance),         # RPC in whole-coin units
                str(format_eth(w3, eth_balance)),   # ETH converted from wei
            ])

    print(f"Balance snapshot saved to {output_path}")


if __name__ == "__main__":
    main()
