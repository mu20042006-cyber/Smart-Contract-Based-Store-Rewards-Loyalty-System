"""
deploy_and_seed.py
──────────────────
Deploy RewardPointCoin and StoreRewards to Ganache, seed three sample reward
items, and mint sample RPC tokens to the test accounts.

Run:
    python admin/deploy_and_seed.py
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent))

from admin_helpers import (
    connect,
    format_token,
    get_contract,
    load_artifact,
    save_deployments,
    wait_for_success,
)


def deploy_contract(w3, contract_name, from_account, constructor_args=None):
    """Compile, deploy, and return the deployed contract address."""
    if constructor_args is None:
        constructor_args = []

    abi, bytecode = load_artifact(contract_name)
    contract = w3.eth.contract(abi=abi, bytecode=bytecode)

    tx_hash = contract.constructor(*constructor_args).transact(
        {"from": from_account, "gas": 6_000_000}
    )
    receipt = wait_for_success(w3, tx_hash, "Deploy " + contract_name)
    print(contract_name + " deployed at " + receipt.contractAddress)
    return receipt.contractAddress


def main():
    w3 = connect()
    admin = w3.eth.accounts[0]
    # Use accounts 1-3 as sample users so we can demonstrate balance/activity.
    users = w3.eth.accounts[1:4]

    print("Deploying contracts…")
    coin_address = deploy_contract(w3, "RewardPointCoin", admin)
    store_address = deploy_contract(w3, "StoreRewards", admin, [coin_address])

    # Persist addresses so every other script can find the contracts.
    save_deployments(
        {
            "StoreRewards": store_address,
            "RewardPointCoin": coin_address,
            "admin": admin,
            "sample_users": users,
        }
    )

    store = get_contract(w3, "StoreRewards", store_address)
    coin = get_contract(w3, "RewardPointCoin", coin_address)

    # ── Seed at least 3 reward items via the batch function ───────────────────
    # Each entry uses arrays; the Solidity for-loop applies each change one by
    # one and requires() the entire batch on any invalid entry.
    item_ids = [0, 1, 2, 3]
    names    = ["Free Coffee", "Snack Box", "Twenty Percent Discount", "Gift Card $5"]
    costs    = [10,            25,          50,                         100]
    stocks   = [100,           50,          25,                         10]
    active   = [True,          True,        True,                        True]

    tx_hash = store.functions.batchSaveRewardItems(
        item_ids,
        names,
        costs,
        stocks,
        active,
    ).transact({"from": admin, "gas": 1_000_000})
    wait_for_success(w3, tx_hash, "Seed reward items")
    print("Seeded", len(names), "reward items.")

    # ── Mint sample RPC tokens to every test user ─────────────────────────────
    for user in users:
        amount = 200 * (10 ** 18)
        tx_hash = coin.functions.mint(user, amount).transact(
            {"from": admin, "gas": 200_000}
        )
        wait_for_success(w3, tx_hash, "Mint sample coins")
        print("Minted", format_token(amount), "RPC →", user)

    print()
    print("Admin account :", admin)
    print("Coin contract  :", coin_address)
    print("Store contract :", store_address)
    print("Deployment details saved to deployments.json")


if __name__ == "__main__":
    main()
