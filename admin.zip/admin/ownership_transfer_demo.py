"""
ownership_transfer_demo.py
──────────────────────────
Demonstrates and verifies the transferOwnership flow:

  Step 1 – Original admin can perform an admin action       → PASS / FAIL
  Step 2 – Transfer both contracts to a new admin           → PASS / FAIL
  Step 3 – Original admin is blocked after transfer         → PASS / FAIL
  Step 4 – New admin can perform admin actions              → PASS / FAIL

Run:
    python admin/ownership_transfer_demo.py
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent))

from admin_helpers import (
    connect,
    get_contract,
    load_deployments,
    save_deployments,
    wait_for_success,
)


def try_admin_action(w3, store, caller):
    """
    Attempt to add/update a reward item as `caller`.
    Returns True if the transaction succeeds, False otherwise.
    """
    try:
        tx_hash = store.functions.addOrUpdateRewardItem(
            0, "Ownership Demo Reward", 15, 10, True,
        ).transact({"from": caller, "gas": 500_000})
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        return receipt.status == 1
    except Exception:
        return False


def main():
    w3 = connect()
    deployments = load_deployments()

    original_admin = deployments["admin"]
    # Pick the second account as the new admin for this demo.
    new_admin = next(
        acc for acc in w3.eth.accounts
        if acc.lower() != original_admin.lower()
    )

    store = get_contract(w3, "StoreRewards",   deployments["StoreRewards"])
    coin  = get_contract(w3, "RewardPointCoin", deployments["RewardPointCoin"])

    print()
    print("Ownership Transfer Demo")
    print("=" * 45)
    print(f"  Original admin : {original_admin}")
    print(f"  New admin      : {new_admin}")
    print()

    # ── Step 1: original admin can act before transfer ─────────────────────
    before_ok = try_admin_action(w3, store, original_admin)
    result1 = "PASS" if before_ok else "FAIL"
    print(f"Step 1 – Original admin performs admin action  → {result1}")

    # ── Step 2: transfer ownership of both contracts ───────────────────────
    try:
        tx = coin.functions.transferOwnership(new_admin).transact(
            {"from": original_admin, "gas": 200_000}
        )
        wait_for_success(w3, tx, "Transfer coin ownership")

        tx = store.functions.transferOwnership(new_admin).transact(
            {"from": original_admin, "gas": 200_000}
        )
        wait_for_success(w3, tx, "Transfer store ownership")
        print("Step 2 – Transfer ownership to new admin       → PASS")
    except Exception as err:
        print("Step 2 – Transfer ownership to new admin       → FAIL:", err)
        return

    # ── Step 3: original admin is blocked after transfer ───────────────────
    old_still_works = try_admin_action(w3, store, original_admin)
    # We WANT this to fail (blocked), so PASS means it returned False.
    result3 = "PASS" if not old_still_works else "FAIL"
    print(f"Step 3 – Original admin is blocked after transfer → {result3}")

    # ── Step 4: new admin can act ──────────────────────────────────────────
    new_ok = try_admin_action(w3, store, new_admin)
    result4 = "PASS" if new_ok else "FAIL"
    print(f"Step 4 – New admin performs admin action          → {result4}")

    # ── Update deployments.json so other scripts use the new admin ─────────
    if new_ok:
        deployments["admin"] = new_admin
        save_deployments(deployments)

    print()
    print(f"Current admin (on-chain): {store.functions.getAdmin().call()}")


if __name__ == "__main__":
    main()
