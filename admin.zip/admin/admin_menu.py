"""
admin_menu.py
─────────────
Password-protected admin menu.

Can be launched directly:
    python admin/admin_menu.py

Or triggered from the user terminal by typing "admin" at the main menu.
"""

import sys
from getpass import getpass
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent))

from admin_dashboard import main as show_dashboard
from admin_helpers import (
    connect,
    get_contract,
    load_deployments,
    save_deployments,
    to_token_units,
    wait_for_success,
)

# ── Admin password (change before production use) ─────────────────────────────
ADMIN_PASSWORD = "admin123"


# ── Helper prompts ────────────────────────────────────────────────────────────

def ask_int(label):
    return int(input(label).strip())


# ── Admin actions ─────────────────────────────────────────────────────────────

def add_or_update_item(w3, store, admin):
    item_id     = ask_int("Reward item id (use next id to add new): ")
    name        = input("Reward item name: ").strip()
    cost        = ask_int("Reward cost in points: ")
    stock       = ask_int("Reward stock quantity: ")
    active_text = input("Active? (yes/no): ").strip().lower()
    active      = active_text in ("yes", "y", "true", "1")

    try:
        tx_hash = store.functions.addOrUpdateRewardItem(
            item_id, name, cost, stock, active,
        ).transact({"from": admin, "gas": 500_000})
        wait_for_success(w3, tx_hash, "Save reward item")
        print("Reward item saved successfully.")
    except Exception as err:
        print("Failed to save item:", err)


def batch_add_items(w3, store, admin):
    """Add or update multiple reward items in a single on-chain transaction."""
    print("Enter reward items one per line. Leave name blank to finish.")
    item_ids, names, costs, stocks, actives = [], [], [], [], []

    while True:
        name = input("  Item name (blank to finish): ").strip()
        if not name:
            break
        item_id = ask_int("  Item id: ")
        cost    = ask_int("  Cost in points: ")
        stock   = ask_int("  Stock quantity: ")
        active_text = input("  Active? (yes/no): ").strip().lower()
        active  = active_text in ("yes", "y", "true", "1")

        item_ids.append(item_id)
        names.append(name)
        costs.append(cost)
        stocks.append(stock)
        actives.append(active)

    if not item_ids:
        print("No items entered.")
        return

    try:
        tx_hash = store.functions.batchSaveRewardItems(
            item_ids, names, costs, stocks, actives,
        ).transact({"from": admin, "gas": 1_000_000})
        wait_for_success(w3, tx_hash, "Batch save reward items")
        print(f"{len(item_ids)} reward items saved in a single transaction.")
    except Exception as err:
        print("Batch save failed:", err)


def mint_coin(w3, coin, admin):
    receiver = input("Receiver address: ").strip()
    amount   = to_token_units(ask_int("Amount of RPC coins to mint: "))

    try:
        tx_hash = coin.functions.mint(receiver, amount).transact(
            {"from": admin, "gas": 200_000}
        )
        wait_for_success(w3, tx_hash, "Mint coins")
        print("Coins minted successfully.")
    except Exception as err:
        print("Mint failed:", err)


def transfer_ownership(w3, store, coin, admin):
    new_admin = input("New admin address: ").strip()
    try:
        tx_hash = coin.functions.transferOwnership(new_admin).transact(
            {"from": admin, "gas": 200_000}
        )
        wait_for_success(w3, tx_hash, "Transfer coin ownership")

        tx_hash = store.functions.transferOwnership(new_admin).transact(
            {"from": admin, "gas": 200_000}
        )
        wait_for_success(w3, tx_hash, "Transfer store ownership")
        print("Both contracts transferred to", new_admin)
    except Exception as err:
        print("Ownership transfer failed:", err)


def set_pause(w3, store, admin, should_pause):
    action = "pause" if should_pause else "resume"
    try:
        if should_pause:
            tx_hash = store.functions.pause().transact({"from": admin, "gas": 200_000})
        else:
            tx_hash = store.functions.resume().transact({"from": admin, "gas": 200_000})
        wait_for_success(w3, tx_hash, action.capitalize() + " store")
        print("Store paused status is now:", store.functions.paused().call())
    except Exception as err:
        print("Pause/resume failed:", err)


# ── Main admin menu loop ──────────────────────────────────────────────────────

def main():
    # ── Password gate: only show the admin section after correct password ──────
    password = getpass("Admin password: ")
    if password != ADMIN_PASSWORD:
        print("Wrong admin password. Access denied.")
        return

    w3 = connect()
    deployments = load_deployments()
    admin = deployments["admin"]

    store = get_contract(w3, "StoreRewards",  deployments["StoreRewards"])
    coin  = get_contract(w3, "RewardPointCoin", deployments["RewardPointCoin"])

    while True:
        print()
        print("Admin Menu – Store Rewards & Points")
        print("-" * 36)
        print("  1.  Show admin dashboard")
        print("  2.  Add or update single reward item")
        print("  3.  Batch add / update reward items")
        print("  4.  Mint Reward Point Coin")
        print("  5.  Pause store")
        print("  6.  Resume store")
        print("  7.  Transfer full admin ownership")
        print("  0.  Exit admin menu")

        choice = input("Choose: ").strip()

        try:
            if choice == "1":
                show_dashboard()
            elif choice == "2":
                add_or_update_item(w3, store, admin)
            elif choice == "3":
                batch_add_items(w3, store, admin)
            elif choice == "4":
                mint_coin(w3, coin, admin)
            elif choice == "5":
                set_pause(w3, store, admin, True)
            elif choice == "6":
                set_pause(w3, store, admin, False)
            elif choice == "7":
                transfer_ownership(w3, store, coin, admin)
                # Update local deployments file with the new admin.
                deployments["admin"] = store.functions.getAdmin().call()
                save_deployments(deployments)
                admin = deployments["admin"]
            elif choice == "0":
                break
            else:
                print("Unknown option. Please try again.")
        except Exception as error:
            print("Admin action failed:", error)


if __name__ == "__main__":
    main()
