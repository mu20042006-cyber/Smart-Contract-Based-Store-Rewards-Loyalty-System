"""
admin_helpers.py
────────────────
Shared utilities used by every admin and system script.
"""

from pathlib import Path
import json

from web3 import Web3


# ── Path constants ────────────────────────────────────────────────────────────

ROOT_DIR = Path(__file__).resolve().parents[1]
BUILD_DIR = ROOT_DIR / "build"
DEPLOYMENTS_FILE = ROOT_DIR / "deployments.json"
GANACHE_URL = "http://127.0.0.1:7545"
TOKEN_DECIMALS = 18
TOKEN_UNIT = 10 ** TOKEN_DECIMALS


# ── Connection ────────────────────────────────────────────────────────────────

def connect():
    """Return a connected Web3 instance pointing at Ganache."""
    w3 = Web3(Web3.HTTPProvider(GANACHE_URL))
    if not w3.is_connected():
        raise RuntimeError("Could not connect to Ganache at " + GANACHE_URL)
    return w3


# ── Contract artifact loading ─────────────────────────────────────────────────

def load_artifact(contract_name):
    """
    Load compiled ABI and bytecode from the build/ directory.

    Accepts either:
      build/<ContractName>.json   (Remix / Hardhat combined artifact)
      build/<ContractName>.abi  + build/<ContractName>.bin
    """
    json_path = BUILD_DIR / (contract_name + ".json")
    abi_path = BUILD_DIR / (contract_name + ".abi")
    bin_path = BUILD_DIR / (contract_name + ".bin")

    if json_path.exists():
        data = json.loads(json_path.read_text())
        abi = data["abi"]
        bytecode = data.get("bytecode")
        if bytecode is None and "evm" in data:
            bytecode = data["evm"]["bytecode"]["object"]
        return abi, bytecode

    if abi_path.exists() and bin_path.exists():
        abi = json.loads(abi_path.read_text())
        bytecode = bin_path.read_text().strip()
        return abi, bytecode

    raise FileNotFoundError(
        "Missing compiled files for " + contract_name +
        ". Add build/" + contract_name + ".abi and build/" + contract_name +
        ".bin (from Remix IDE)."
    )


# ── Deployments file ──────────────────────────────────────────────────────────

def load_deployments():
    """Load contract addresses saved by deploy_and_seed.py."""
    if not DEPLOYMENTS_FILE.exists():
        raise FileNotFoundError("Run admin/deploy_and_seed.py first.")
    return json.loads(DEPLOYMENTS_FILE.read_text())


def save_deployments(deployments):
    """Persist contract addresses and metadata to deployments.json."""
    DEPLOYMENTS_FILE.write_text(json.dumps(deployments, indent=2))


# ── Contract factory ──────────────────────────────────────────────────────────

def get_contract(w3, contract_name, address):
    """Return a bound web3 contract object for the given deployed address."""
    abi, _ = load_artifact(contract_name)
    return w3.eth.contract(
        address=Web3.to_checksum_address(address),
        abi=abi,
    )


def get_deployed_contracts(w3):
    """Convenience wrapper: load deployments then return (deployments, store, coin)."""
    deployments = load_deployments()
    store = get_contract(w3, "StoreRewards", deployments["StoreRewards"])
    coin = get_contract(w3, "RewardPointCoin", deployments["RewardPointCoin"])
    return deployments, store, coin


# ── Token / ETH formatting ────────────────────────────────────────────────────

def format_token(raw_amount):
    """Convert raw 18-decimal token amount to a human-readable float."""
    return raw_amount / TOKEN_UNIT


def to_token_units(point_amount):
    """Convert a whole-number coin amount to the raw 18-decimal value."""
    return int(point_amount) * TOKEN_UNIT


def format_eth(w3, raw_amount):
    """Convert wei to ether using web3.from_wei."""
    return w3.from_wei(raw_amount, "ether")


# ── Transaction helpers ───────────────────────────────────────────────────────

def wait_for_success(w3, tx_hash, label):
    """
    Block until the transaction is mined.  Raise RuntimeError on failure.
    Returns the receipt on success.
    """
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    if receipt.status != 1:
        raise RuntimeError(label + " transaction failed")
    return receipt


# ── Block scanning ────────────────────────────────────────────────────────────

def scan_contract_transactions(w3, contract_addresses):
    """
    Scan every block from 0 to the current head.
    Returns (total_tx_count, top_3_senders) where top_3_senders is a list of
    (address, count) tuples sorted by count descending.
    """
    targets = {address.lower() for address in contract_addresses}
    tx_count = 0
    sender_counts = {}

    for block_number in range(w3.eth.block_number + 1):
        block = w3.eth.get_block(block_number, full_transactions=True)
        for tx in block.transactions:
            to_address = tx["to"]
            if to_address is None or to_address.lower() not in targets:
                continue

            tx_count += 1
            sender = tx["from"]
            sender_counts[sender] = sender_counts.get(sender, 0) + 1

    top_users = sorted(
        sender_counts.items(),
        key=lambda row: row[1],
        reverse=True,
    )[:3]
    return tx_count, top_users


# ── Known accounts helper ─────────────────────────────────────────────────────

def get_known_accounts(w3, deployments=None):
    """Return a sorted list of every known Ganache + deployment account."""
    accounts = set(w3.eth.accounts)
    if deployments:
        accounts.add(deployments.get("admin", ""))
        for user in deployments.get("sample_users", []):
            accounts.add(user)
    return sorted(account for account in accounts if account)
