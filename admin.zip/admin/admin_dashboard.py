"""
admin_dashboard.py
──────────────────
Print a summary of the whole Store Rewards system.

All data is pulled live from the blockchain (block-range loop + contract
view functions) – nothing is hardcoded.

Run:
    python admin/admin_dashboard.py
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent))

from admin_helpers import (
    connect,
    format_token,
    get_contract,
    load_deployments,
    scan_contract_transactions,
)


def print_top_users_table(rows):
    """Print the top-3 active addresses in an aligned table."""
    if not rows:
        print("  (no contract transactions found yet)")
        return

    print(f"  {'Rank':<5}  {'Address':<44}  {'Transactions':>12}")
    print(f"  {'----':<5}  {'-------':<44}  {'------------':>12}")
    for rank, (address, count) in enumerate(rows, start=1):
        print(f"  {rank:<5}  {address:<44}  {count:>12}")


def main():
    w3 = connect()
    deployments = load_deployments()

    store_address = deployments["StoreRewards"]
    coin_address  = deployments["RewardPointCoin"]

    store = get_contract(w3, "StoreRewards", store_address)
    coin  = get_contract(w3, "RewardPointCoin", coin_address)

    # ── Read contract state ───────────────────────────────────────────────────
    item_count   = store.functions.getRewardItemCount().call()
    total_supply = coin.functions.totalSupply().call()
    current_admin = store.functions.getAdmin().call()
    is_paused    = store.functions.paused().call()

    # ── Scan blockchain for transaction stats ─────────────────────────────────
    # scan_contract_transactions iterates every block from 0 to the current
    # head, filters transactions whose `to` address is one of our contracts,
    # and tallies the sender counts.
    transaction_count, top_users = scan_contract_transactions(
        w3, [store_address, coin_address]
    )

    # ── Print summary ─────────────────────────────────────────────────────────
    print()
    print("Admin Dashboard – Store Rewards & Points")
    print("=" * 45)
    print(f"  Current admin              : {current_admin}")
    print(f"  Store paused               : {is_paused}")
    print(f"  Total reward items         : {item_count}")
    print(f"  Total RPC minted           : {format_token(total_supply)} RPC")
    print(f"  Total contract transactions: {transaction_count}")
    print()
    print("  Top 3 Most Active Addresses")
    print_top_users_table(top_users)
    print()


if __name__ == "__main__":
    main()
