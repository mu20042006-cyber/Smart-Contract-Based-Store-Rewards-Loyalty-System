"""
security_test.py
────────────────
Automated security test: verifies that onlyOwner blocks non-admin callers.

For every sensitive admin function the test:
  1. Confirms the admin CAN call it (transaction succeeds).
  2. Asserts that a normal user CANNOT call it (transaction reverts).

Each revert check uses a Python `assert` statement so that any unexpected
success raises an AssertionError and the overall test fails immediately.

Run:
    python tests/security_test.py
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1] / "admin"))

from admin_helpers import connect, get_contract, load_deployments


# ── Helpers ────────────────────────────────────────────────────────────────────

def attempt_tx(w3, fn, caller, gas=500_000):
    """
    Try to broadcast a transaction as `caller`.
    Returns True  if the receipt status is 1 (success).
    Returns False if the call reverts or raises any exception.
    """
    try:
        tx_hash = fn.transact({"from": caller, "gas": gas})
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        return receipt.status == 1
    except Exception:
        # web3.py raises ContractLogicError / ValueError on revert.
        return False


def assert_succeeds(label, w3, fn, caller):
    """Assert the transaction succeeds; print PASS / FAIL."""
    ok = attempt_tx(w3, fn, caller)
    assert ok, f"ASSERTION FAILED: expected '{label}' to succeed but it was blocked."
    print(f"  PASS  {label} → succeeded")
    return True


def assert_reverts(label, w3, fn, caller):
    """
    Assert the transaction is REVERTED (non-admin call must be blocked).
    Uses a Python `assert` to verify the revert happened.
    Prints PASS if the assertion holds, FAIL otherwise.
    Returns True/False so the caller can track the overall result.
    """
    blocked = not attempt_tx(w3, fn, caller)
    # The critical assertion: the non-admin call MUST revert.
    try:
        assert blocked, (
            f"SECURITY HOLE: non-admin was able to call '{label}'. "
            "onlyOwner modifier is not enforced."
        )
        print(f"  PASS  {label} → transaction reverted (blocked as expected)")
        return True
    except AssertionError as err:
        print(f"  FAIL  {label} → {err}")
        return False


# ── Main test suite ────────────────────────────────────────────────────────────

def main():
    w3 = connect()
    deployments = load_deployments()

    admin = deployments["admin"]

    # Pick any account that is NOT the admin to act as the attacker.
    normal_user = next(
        acc for acc in w3.eth.accounts
        if acc.lower() != admin.lower()
    )

    # A third address used as a transfer target (ownership never actually moved).
    third = next(
        acc for acc in w3.eth.accounts
        if acc.lower() not in (admin.lower(), normal_user.lower())
    )

    store = get_contract(w3, "StoreRewards",   deployments["StoreRewards"])
    coin  = get_contract(w3, "RewardPointCoin", deployments["RewardPointCoin"])

    all_pass = True

    print()
    print("Security Test – onlyOwner blocks non-admin callers")
    print("=" * 54)

    # ── Test 1: addOrUpdateRewardItem ──────────────────────────────────────
    print()
    print("1. addOrUpdateRewardItem (StoreRewards)")
    all_pass &= assert_succeeds(
        "admin calls addOrUpdateRewardItem",
        w3,
        store.functions.addOrUpdateRewardItem(0, "Security Test Item", 20, 5, True),
        admin,
    )
    # Assert: non-admin transaction must revert.
    all_pass &= assert_reverts(
        "non-admin calls addOrUpdateRewardItem",
        w3,
        store.functions.addOrUpdateRewardItem(0, "Attacker Item", 1, 1, True),
        normal_user,
    )

    # ── Test 2: batchSaveRewardItems ───────────────────────────────────────
    print()
    print("2. batchSaveRewardItems (StoreRewards)")
    all_pass &= assert_succeeds(
        "admin calls batchSaveRewardItems",
        w3,
        store.functions.batchSaveRewardItems([0], ["Batch OK"], [10], [5], [True]),
        admin,
    )
    # Assert: non-admin batch transaction must revert.
    all_pass &= assert_reverts(
        "non-admin calls batchSaveRewardItems",
        w3,
        store.functions.batchSaveRewardItems([0], ["Batch Attack"], [10], [5], [True]),
        normal_user,
    )

    # ── Test 3: pause ──────────────────────────────────────────────────────
    print()
    print("3. pause() (StoreRewards)")
    all_pass &= assert_succeeds(
        "admin calls pause()", w3, store.functions.pause(), admin,
    )
    # Assert: non-admin pause must revert.
    all_pass &= assert_reverts(
        "non-admin calls pause()", w3, store.functions.pause(), normal_user,
    )

    # ── Test 4: resume ─────────────────────────────────────────────────────
    print()
    print("4. resume() (StoreRewards)")
    all_pass &= assert_succeeds(
        "admin calls resume()", w3, store.functions.resume(), admin,
    )
    # Assert: non-admin resume must revert.
    all_pass &= assert_reverts(
        "non-admin calls resume()", w3, store.functions.resume(), normal_user,
    )

    # ── Test 5: mint (RewardPointCoin) ─────────────────────────────────────
    print()
    print("5. mint() (RewardPointCoin)")
    all_pass &= assert_succeeds(
        "admin calls mint()", w3, coin.functions.mint(admin, 10 ** 18), admin,
    )
    # Assert: non-admin mint must revert.
    all_pass &= assert_reverts(
        "non-admin calls mint()", w3, coin.functions.mint(normal_user, 10 ** 18), normal_user,
    )

    # ── Test 6: transferOwnership (StoreRewards) ───────────────────────────
    print()
    print("6. transferOwnership() (StoreRewards)")
    # Only test the non-admin path (we don't want to change ownership here).
    # Assert: non-admin ownership transfer must revert.
    all_pass &= assert_reverts(
        "non-admin calls store.transferOwnership()",
        w3, store.functions.transferOwnership(third), normal_user,
    )

    # ── Test 7: transferOwnership (RewardPointCoin) ────────────────────────
    print()
    print("7. transferOwnership() (RewardPointCoin)")
    # Assert: non-admin coin ownership transfer must revert.
    all_pass &= assert_reverts(
        "non-admin calls coin.transferOwnership()",
        w3, coin.functions.transferOwnership(third), normal_user,
    )

    # ── Final summary ──────────────────────────────────────────────────────
    print()
    print("=" * 54)
    if all_pass:
        print("ALL TESTS PASSED – access control is working correctly.")
    else:
        print("SOME TESTS FAILED – review the output above.")
    print()


if __name__ == "__main__":
    main()
