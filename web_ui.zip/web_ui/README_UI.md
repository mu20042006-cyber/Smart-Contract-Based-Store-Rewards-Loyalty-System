# Premium Web UI Layer

This UI is an additional Streamlit frontend for the existing **Store Rewards & Points DApp**.
It does **not** replace or edit the original terminal, admin, Solidity, transaction, or helper files.

## Run

From the project root:

```bash
pip install -r requirements.txt
pip install -r requirements_ui.txt
python admin/deploy_and_seed.py
streamlit run web_ui/app.py
```

Ganache must be running on:

```text
http://127.0.0.1:7545
```

## What the UI includes

- Premium glassmorphism dashboard
- Live contract status cards
- Wallet selector and balance cards
- On-chain profile registration
- Reward cards with redeem buttons
- Activity search by address
- Admin controls for items, minting, pause/resume, and ownership transfer

## Original code status

The original project files are kept intact. The added files are:

```text
web_ui/app.py
web_ui/README_UI.md
requirements_ui.txt
```
