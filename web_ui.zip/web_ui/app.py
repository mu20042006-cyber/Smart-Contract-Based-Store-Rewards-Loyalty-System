"""
Premium Streamlit UI for the Store Rewards & Points DApp.

This file is intentionally separated from the original terminal/admin/blockchain
code. It only adds a visual web layer and calls the same deployed contracts.

Run from the project root:
    streamlit run web_ui/app.py
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

import streamlit as st

ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT_DIR / "admin"))
sys.path.append(str(ROOT_DIR / "user"))

from admin_helpers import (  # noqa: E402
    connect,
    format_eth,
    format_token,
    get_contract,
    load_deployments,
    scan_contract_transactions,
    to_token_units,
    wait_for_success,
)
from transaction_sender import find_activity_rows  # noqa: E402

ADMIN_PASSWORD = "admin123"


# ─────────────────────────────────────────────────────────────────────────────
# Page setup + visual system
# ─────────────────────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="Store Rewards | Premium DApp",
    page_icon="◆",
    layout="wide",
    initial_sidebar_state="expanded",
)

PREMIUM_CSS = """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');

    :root {
        --bg-0: #060711;
        --bg-1: #0b1023;
        --card: rgba(255,255,255,0.074);
        --card-strong: rgba(255,255,255,0.12);
        --stroke: rgba(255,255,255,0.18);
        --text: #f7f8ff;
        --muted: rgba(238,242,255,0.66);
        --gold: #ffd166;
        --cyan: #45f3ff;
        --violet: #a78bfa;
        --rose: #fb7185;
        --green: #86efac;
    }

    html, body, [class*="css"] {
        font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    }

    .stApp {
        color: var(--text);
        background:
            radial-gradient(circle at 18% 12%, rgba(69, 243, 255, 0.22), transparent 27%),
            radial-gradient(circle at 82% 4%, rgba(167, 139, 250, 0.23), transparent 31%),
            radial-gradient(circle at 52% 88%, rgba(251, 113, 133, 0.16), transparent 34%),
            linear-gradient(135deg, #050713 0%, #0b1023 48%, #030712 100%);
    }

    .stApp::before {
        content: "";
        position: fixed;
        inset: 0;
        pointer-events: none;
        background-image:
            linear-gradient(rgba(255,255,255,0.028) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.028) 1px, transparent 1px);
        background-size: 58px 58px;
        mask-image: linear-gradient(to bottom, rgba(0,0,0,0.95), rgba(0,0,0,0.18));
        z-index: 0;
    }

    .block-container {
        padding-top: 2rem;
        padding-bottom: 3rem;
        max-width: 1450px;
        position: relative;
        z-index: 1;
    }

    section[data-testid="stSidebar"] {
        background:
            linear-gradient(180deg, rgba(8, 13, 31, 0.96), rgba(4, 8, 20, 0.96)),
            radial-gradient(circle at 20% 0%, rgba(69, 243, 255, 0.16), transparent 42%);
        border-right: 1px solid rgba(255,255,255,0.12);
    }

    section[data-testid="stSidebar"] * {
        color: #f8fbff;
    }

    div[data-testid="stMetric"] {
        background: linear-gradient(145deg, rgba(255,255,255,0.14), rgba(255,255,255,0.055));
        border: 1px solid rgba(255,255,255,0.14);
        border-radius: 24px;
        padding: 20px 20px 18px 20px;
        box-shadow: 0 24px 80px rgba(0,0,0,0.27), inset 0 1px 0 rgba(255,255,255,0.16);
        backdrop-filter: blur(18px);
    }

    div[data-testid="stMetricValue"] {
        font-weight: 900;
        letter-spacing: -0.04em;
    }

    .hero {
        position: relative;
        overflow: hidden;
        border-radius: 34px;
        padding: 34px 34px 30px;
        background:
            linear-gradient(135deg, rgba(255,255,255,0.16), rgba(255,255,255,0.055)),
            radial-gradient(circle at 14% 12%, rgba(69,243,255,0.27), transparent 30%),
            radial-gradient(circle at 86% 24%, rgba(255,209,102,0.23), transparent 30%);
        border: 1px solid rgba(255,255,255,0.18);
        box-shadow: 0 28px 90px rgba(0,0,0,0.36), inset 0 1px 0 rgba(255,255,255,0.18);
        backdrop-filter: blur(22px);
        margin-bottom: 22px;
    }

    .hero::after {
        content: "";
        position: absolute;
        width: 420px;
        height: 420px;
        right: -180px;
        top: -170px;
        background: conic-gradient(from 180deg, rgba(69,243,255,0.0), rgba(69,243,255,0.40), rgba(167,139,250,0.32), rgba(255,209,102,0.22), rgba(69,243,255,0.0));
        filter: blur(18px);
        opacity: 0.82;
        animation: orbspin 15s linear infinite;
    }

    @keyframes orbspin {
        from { transform: rotate(0deg) scale(1); }
        to { transform: rotate(360deg) scale(1.08); }
    }

    .eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 9px;
        padding: 8px 13px;
        border-radius: 999px;
        background: rgba(255,255,255,0.10);
        border: 1px solid rgba(255,255,255,0.16);
        color: rgba(248,251,255,0.84);
        font-size: 0.82rem;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        margin-bottom: 18px;
    }

    .hero h1 {
        font-size: clamp(2.7rem, 5.8vw, 6.4rem);
        line-height: 0.92;
        margin: 0;
        letter-spacing: -0.085em;
        font-weight: 950;
        max-width: 960px;
        color: #ffffff;
    }

    .hero h1 span {
        background: linear-gradient(90deg, var(--cyan), #ffffff 40%, var(--gold));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    .hero p {
        margin: 20px 0 0;
        color: rgba(248,251,255,0.72);
        max-width: 800px;
        font-size: 1.05rem;
        line-height: 1.75;
    }

    .glass-card {
        border-radius: 28px;
        padding: 24px;
        background: linear-gradient(145deg, rgba(255,255,255,0.13), rgba(255,255,255,0.055));
        border: 1px solid rgba(255,255,255,0.15);
        box-shadow: 0 20px 70px rgba(0,0,0,0.28), inset 0 1px 0 rgba(255,255,255,0.16);
        backdrop-filter: blur(18px);
        margin-bottom: 18px;
    }

    .mini-card {
        border-radius: 24px;
        padding: 20px;
        background:
            linear-gradient(160deg, rgba(255,255,255,0.14), rgba(255,255,255,0.055)),
            radial-gradient(circle at 10% 10%, rgba(69,243,255,0.13), transparent 35%);
        border: 1px solid rgba(255,255,255,0.15);
        min-height: 190px;
        box-shadow: 0 18px 55px rgba(0,0,0,0.22);
        transition: transform 0.18s ease, border-color 0.18s ease, background 0.18s ease;
    }

    .mini-card:hover {
        transform: translateY(-5px);
        border-color: rgba(69,243,255,0.44);
        background:
            linear-gradient(160deg, rgba(255,255,255,0.19), rgba(255,255,255,0.07)),
            radial-gradient(circle at 10% 10%, rgba(69,243,255,0.22), transparent 35%);
    }

    .mini-card h3 {
        margin: 0 0 12px;
        font-size: 1.32rem;
        font-weight: 850;
        letter-spacing: -0.04em;
        color: #fff;
    }

    .muted { color: rgba(248,251,255,0.66); }
    .tiny { font-size: 0.78rem; }

    .pill-row {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 12px;
    }

    .pill {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 8px 11px;
        border-radius: 999px;
        border: 1px solid rgba(255,255,255,0.13);
        background: rgba(255,255,255,0.085);
        color: rgba(248,251,255,0.78);
        font-size: 0.83rem;
        font-weight: 650;
    }

    .status-on {
        color: #04120a;
        background: linear-gradient(90deg, #86efac, #d9f99d);
        border-color: rgba(134,239,172,0.6);
    }

    .status-off {
        color: #1b0d0f;
        background: linear-gradient(90deg, #fb7185, #fecdd3);
        border-color: rgba(251,113,133,0.6);
    }

    .address-chip {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        padding: 10px 12px;
        border-radius: 16px;
        background: rgba(0,0,0,0.28);
        border: 1px solid rgba(255,255,255,0.11);
        color: rgba(248,251,255,0.78);
        overflow-wrap: anywhere;
    }

    .section-title {
        margin: 12px 0 14px;
        font-weight: 900;
        letter-spacing: -0.05em;
        font-size: 2rem;
        color: #fff;
    }

    .subtle-line {
        height: 1px;
        width: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
        margin: 20px 0;
    }

    .stButton > button, .stDownloadButton > button, button[kind="primary"] {
        border-radius: 16px !important;
        border: 1px solid rgba(255,255,255,0.20) !important;
        background: linear-gradient(135deg, rgba(69,243,255,0.95), rgba(167,139,250,0.94)) !important;
        color: #050713 !important;
        font-weight: 850 !important;
        box-shadow: 0 12px 32px rgba(69,243,255,0.18) !important;
        transition: all 0.18s ease !important;
    }

    .stButton > button:hover, .stDownloadButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 18px 44px rgba(69,243,255,0.25) !important;
        border-color: rgba(255,255,255,0.42) !important;
    }

    div[data-baseweb="tab-list"] {
        gap: 10px;
        background: rgba(255,255,255,0.07);
        border: 1px solid rgba(255,255,255,0.11);
        border-radius: 22px;
        padding: 8px;
        backdrop-filter: blur(16px);
    }

    button[data-baseweb="tab"] {
        border-radius: 16px !important;
        padding: 10px 18px !important;
        font-weight: 800 !important;
    }

    div[data-baseweb="tab-highlight"] { display: none; }

    [data-testid="stDataFrame"] {
        border-radius: 20px;
        overflow: hidden;
        border: 1px solid rgba(255,255,255,0.14);
    }

    .warning-card {
        border-radius: 24px;
        padding: 22px;
        background: linear-gradient(135deg, rgba(255,209,102,0.18), rgba(251,113,133,0.12));
        border: 1px solid rgba(255,209,102,0.34);
        color: #fff;
    }

    input, textarea, select {
        border-radius: 14px !important;
    }
</style>
"""

st.markdown(PREMIUM_CSS, unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def short_address(address: str, left: int = 6, right: int = 4) -> str:
    if not address:
        return "—"
    if len(address) <= left + right + 3:
        return address
    return f"{address[:left]}…{address[-right:]}"


def section(title: str, subtitle: str | None = None) -> None:
    st.markdown(f"<div class='section-title'>{title}</div>", unsafe_allow_html=True)
    if subtitle:
        st.markdown(f"<div class='muted'>{subtitle}</div>", unsafe_allow_html=True)


def load_runtime() -> Tuple[Any, Dict[str, Any], Any, Any]:
    w3 = connect()
    deployments = load_deployments()
    store = get_contract(w3, "StoreRewards", deployments["StoreRewards"])
    coin = get_contract(w3, "RewardPointCoin", deployments["RewardPointCoin"])
    return w3, deployments, store, coin


def get_items(store: Any) -> List[Dict[str, Any]]:
    count = store.functions.getRewardItemCount().call()
    rows: List[Dict[str, Any]] = []
    for item_id in range(count):
        name, cost, stock, active = store.functions.getRewardItem(item_id).call()
        rows.append(
            {
                "id": item_id,
                "name": name,
                "cost": int(cost),
                "stock": int(stock),
                "active": bool(active),
            }
        )
    return rows


def get_registered_name(store: Any, account: str) -> str:
    if store.functions.registeredUsers(account).call():
        return store.functions.userNames(account).call()
    return "Unregistered user"


def get_balances(w3: Any, coin: Any, account: str) -> Tuple[float, Any]:
    rpc_balance = format_token(coin.functions.balanceOf(account).call())
    eth_balance = format_eth(w3, w3.eth.get_balance(account))
    return rpc_balance, eth_balance


def safe_wait(w3: Any, tx_hash: Any, label: str) -> None:
    with st.spinner(f"Processing {label} transaction..."):
        wait_for_success(w3, tx_hash, label)
    st.success(f"{label} completed successfully.")
    st.cache_data.clear()


def store_status_badge(is_paused: bool) -> str:
    klass = "status-off" if is_paused else "status-on"
    text = "Paused" if is_paused else "Live"
    return f"<span class='pill {klass}'>● {text}</span>"


def item_card(item: Dict[str, Any]) -> None:
    badge = "status-on" if item["active"] and item["stock"] > 0 else "status-off"
    status = "Available" if item["active"] and item["stock"] > 0 else "Unavailable"
    st.markdown(
        f"""
        <div class="mini-card">
            <div class="tiny muted">Reward #{item['id']}</div>
            <h3>{item['name']}</h3>
            <div class="pill-row">
                <span class="pill">◆ {item['cost']} RPC</span>
                <span class="pill">Stock: {item['stock']}</span>
                <span class="pill {badge}">● {status}</span>
            </div>
            <div class="subtle-line"></div>
            <div class="muted tiny">Redeem directly from your selected Ganache wallet.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_setup_error(error: Exception) -> None:
    st.markdown(
        """
        <div class="hero">
            <div class="eyebrow">◆ Premium UI Layer</div>
            <h1>Interface ready.<br><span>Blockchain setup required.</span></h1>
            <p>
                The new visual layer is installed, but the app could not load the live Ganache deployment.
                Start Ganache, compile the contracts, deploy/seed them, then run this UI again.
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.markdown("<div class='warning-card'>", unsafe_allow_html=True)
    st.error(str(error))
    st.code(
        """pip install -r requirements.txt
pip install -r requirements_ui.txt
python admin/deploy_and_seed.py
streamlit run web_ui/app.py""",
        language="bash",
    )
    st.markdown("</div>", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# Load app
# ─────────────────────────────────────────────────────────────────────────────

try:
    w3, deployments, store, coin = load_runtime()
except Exception as exc:  # UI-only graceful setup screen
    render_setup_error(exc)
    st.stop()

accounts = list(w3.eth.accounts)
admin_address = deployments.get("admin", "")
store_address = deployments.get("StoreRewards", "")
coin_address = deployments.get("RewardPointCoin", "")

with st.sidebar:
    st.markdown("## ◆ Store Rewards")
    st.caption("Premium web UI layer")
    st.markdown("<div class='subtle-line'></div>", unsafe_allow_html=True)

    selected_account = st.selectbox(
        "Active wallet",
        options=accounts,
        format_func=lambda value: (
            f"{short_address(value)}  ·  {'admin' if value.lower() == admin_address.lower() else 'user'}"
        ),
    )

    display_name = get_registered_name(store, selected_account)
    rpc_balance, eth_balance = get_balances(w3, coin, selected_account)

    st.markdown(f"<div class='address-chip'>{selected_account}</div>", unsafe_allow_html=True)
    st.markdown(" ")
    st.metric("Profile", display_name)
    st.metric("RPC Balance", f"{rpc_balance:g}")
    st.metric("ETH Balance", f"{float(eth_balance):.4f}")
    st.markdown("<div class='subtle-line'></div>", unsafe_allow_html=True)
    st.caption("The original Python, Solidity, admin, and terminal files are not edited by this UI.")

items = get_items(store)
item_count = len(items)
active_items = sum(1 for item in items if item["active"])
total_stock = sum(item["stock"] for item in items)
total_supply = format_token(coin.functions.totalSupply().call())
is_paused = bool(store.functions.paused().call())

st.markdown(
    f"""
    <div class="hero">
        <div class="eyebrow">◆ Live Ganache DApp · Glass UI</div>
        <h1>Rewards that feel<br><span>premium on-chain.</span></h1>
        <p>
            A polished web interface for browsing rewards, checking balances, reviewing activity,
            and managing admin actions while keeping the original blockchain logic untouched.
        </p>
        <div class="pill-row">
            {store_status_badge(is_paused)}
            <span class="pill">Store {short_address(store_address)}</span>
            <span class="pill">Coin {short_address(coin_address)}</span>
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)

m1, m2, m3, m4 = st.columns(4)
m1.metric("Reward Items", item_count)
m2.metric("Active Items", active_items)
m3.metric("Total Stock", total_stock)
m4.metric("Total RPC Minted", f"{total_supply:g}")

store_tab, wallet_tab, activity_tab, admin_tab = st.tabs(
    ["◆ Store", "◈ Wallet", "◇ Activity", "✦ Admin"]
)


# ─────────────────────────────────────────────────────────────────────────────
# Store tab
# ─────────────────────────────────────────────────────────────────────────────

with store_tab:
    section("Reward Store", "Browse live items from the deployed StoreRewards contract.")

    if is_paused:
        st.warning("The store is currently paused. User actions are blocked until the admin resumes it.")

    if display_name == "Unregistered user":
        with st.container(border=True):
            st.subheader("Create your on-chain profile")
            name = st.text_input("Display name", placeholder="Example: Omar")
            if st.button("Register this wallet", use_container_width=True, type="primary"):
                if not name.strip():
                    st.error("Please enter a display name.")
                else:
                    try:
                        tx = store.functions.registerUser(name.strip()).transact(
                            {"from": selected_account, "gas": 250_000}
                        )
                        safe_wait(w3, tx, "Register user")
                        st.rerun()
                    except Exception as err:
                        st.error(f"Registration failed: {err}")

    if not items:
        st.info("No reward items found yet. Add items from the Admin tab.")
    else:
        columns = st.columns(3)
        for index, item in enumerate(items):
            with columns[index % 3]:
                item_card(item)
                disabled = (
                    is_paused
                    or display_name == "Unregistered user"
                    or not item["active"]
                    or item["stock"] <= 0
                    or rpc_balance < item["cost"]
                )
                if st.button(
                    f"Redeem {item['name']}",
                    key=f"redeem-{item['id']}",
                    disabled=disabled,
                    use_container_width=True,
                ):
                    try:
                        payment_amount = to_token_units(item["cost"])
                        approve_tx = coin.functions.approve(store_address, payment_amount).transact(
                            {"from": selected_account, "gas": 200_000}
                        )
                        safe_wait(w3, approve_tx, "Approve reward payment")
                        redeem_tx = store.functions.redeemReward(item["id"]).transact(
                            {"from": selected_account, "gas": 400_000}
                        )
                        safe_wait(w3, redeem_tx, "Redeem reward")
                        st.balloons()
                        st.rerun()
                    except Exception as err:
                        st.error(f"Redemption failed: {err}")


# ─────────────────────────────────────────────────────────────────────────────
# Wallet tab
# ─────────────────────────────────────────────────────────────────────────────

with wallet_tab:
    section("Wallet Command Center", "Inspect balances and account identity with a polished dashboard.")
    c1, c2 = st.columns([1, 1])
    with c1:
        st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
        st.subheader("Selected wallet")
        st.markdown(f"<div class='address-chip'>{selected_account}</div>", unsafe_allow_html=True)
        st.markdown(" ")
        st.write(f"**Display name:** {display_name}")
        st.write(f"**Role:** {'Admin' if selected_account.lower() == admin_address.lower() else 'User'}")
        st.write(f"**Status:** {'Registered' if display_name != 'Unregistered user' else 'Not registered'}")
        st.markdown("</div>", unsafe_allow_html=True)

    with c2:
        st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
        st.subheader("Balances")
        b1, b2 = st.columns(2)
        b1.metric("RPC", f"{rpc_balance:g}")
        b2.metric("ETH", f"{float(eth_balance):.6f}")
        st.caption("Balances are read live from Ganache through web3.py.")
        st.markdown("</div>", unsafe_allow_html=True)

    with st.expander("Check another address"):
        other_address = st.text_input("Address", placeholder="0x...")
        if st.button("Check balance", use_container_width=True):
            if not other_address.strip():
                st.error("Enter an address first.")
            else:
                try:
                    other_rpc, other_eth = get_balances(w3, coin, other_address.strip())
                    x1, x2 = st.columns(2)
                    x1.metric("RPC", f"{other_rpc:g}")
                    x2.metric("ETH", f"{float(other_eth):.6f}")
                except Exception as err:
                    st.error(f"Could not retrieve balance: {err}")


# ─────────────────────────────────────────────────────────────────────────────
# Activity tab
# ─────────────────────────────────────────────────────────────────────────────

with activity_tab:
    section("On-chain Activity", "Search activity by wallet address using the original block-scanning approach.")
    search_address = st.text_input("Activity address", value=selected_account)
    if st.button("Load activity", use_container_width=True, type="primary"):
        try:
            rows = find_activity_rows(w3, store, coin, search_address.strip())
            if rows:
                table_rows = [
                    {"Block": block, "Action": action, "Value": value}
                    for block, action, value in rows
                ]
                st.dataframe(table_rows, use_container_width=True, hide_index=True)
            else:
                st.info("No activity found for this address.")
        except Exception as err:
            st.error(f"Activity scan failed: {err}")

    with st.expander("System-wide transaction snapshot"):
        try:
            tx_count, top_users = scan_contract_transactions(w3, [store_address, coin_address])
            st.metric("Total contract transactions", tx_count)
            if top_users:
                st.dataframe(
                    [
                        {"Rank": i + 1, "Address": address, "Transactions": count}
                        for i, (address, count) in enumerate(top_users)
                    ],
                    use_container_width=True,
                    hide_index=True,
                )
            else:
                st.info("No contract transactions found yet.")
        except Exception as err:
            st.error(f"Could not scan transactions: {err}")


# ─────────────────────────────────────────────────────────────────────────────
# Admin tab
# ─────────────────────────────────────────────────────────────────────────────

with admin_tab:
    section("Admin Console", "Password-protected controls with the same admin permissions as the original CLI.")

    password = st.text_input("Admin password", type="password")

    if password != ADMIN_PASSWORD:
        st.info("Enter the admin password to unlock management controls.")
    else:
        st.success(f"Admin unlocked. Current admin: {short_address(admin_address)}")

        a1, a2 = st.columns(2)
        with a1:
            with st.container(border=True):
                st.subheader("Add or update reward item")
                default_next_id = item_count
                item_id = st.number_input("Item ID", min_value=0, value=default_next_id, step=1)
                item_name = st.text_input("Reward name", placeholder="Premium voucher")
                item_cost = st.number_input("Cost in RPC", min_value=1, value=25, step=1)
                item_stock = st.number_input("Stock quantity", min_value=0, value=10, step=1)
                item_active = st.toggle("Active", value=True)
                if st.button("Save reward item", use_container_width=True, type="primary"):
                    if not item_name.strip():
                        st.error("Reward name cannot be empty.")
                    else:
                        try:
                            tx = store.functions.addOrUpdateRewardItem(
                                int(item_id), item_name.strip(), int(item_cost), int(item_stock), bool(item_active)
                            ).transact({"from": admin_address, "gas": 500_000})
                            safe_wait(w3, tx, "Save reward item")
                            st.rerun()
                        except Exception as err:
                            st.error(f"Save failed: {err}")

        with a2:
            with st.container(border=True):
                st.subheader("Mint RPC coins")
                receiver = st.selectbox(
                    "Receiver",
                    options=accounts,
                    format_func=lambda value: short_address(value),
                    key="mint-receiver",
                )
                amount = st.number_input("Amount", min_value=1, value=100, step=1)
                if st.button("Mint coins", use_container_width=True):
                    try:
                        tx = coin.functions.mint(receiver, to_token_units(int(amount))).transact(
                            {"from": admin_address, "gas": 200_000}
                        )
                        safe_wait(w3, tx, "Mint coins")
                        st.rerun()
                    except Exception as err:
                        st.error(f"Mint failed: {err}")

        p1, p2, p3 = st.columns(3)
        with p1:
            if st.button("Pause store", use_container_width=True, disabled=is_paused):
                try:
                    tx = store.functions.pause().transact({"from": admin_address, "gas": 200_000})
                    safe_wait(w3, tx, "Pause store")
                    st.rerun()
                except Exception as err:
                    st.error(f"Pause failed: {err}")
        with p2:
            if st.button("Resume store", use_container_width=True, disabled=not is_paused):
                try:
                    tx = store.functions.resume().transact({"from": admin_address, "gas": 200_000})
                    safe_wait(w3, tx, "Resume store")
                    st.rerun()
                except Exception as err:
                    st.error(f"Resume failed: {err}")
        with p3:
            with st.popover("Transfer ownership"):
                new_admin = st.selectbox(
                    "New admin",
                    options=accounts,
                    format_func=lambda value: short_address(value),
                    key="new-admin",
                )
                st.warning("This transfers both StoreRewards and RewardPointCoin ownership.")
                if st.button("Confirm transfer", use_container_width=True):
                    try:
                        coin_tx = coin.functions.transferOwnership(new_admin).transact(
                            {"from": admin_address, "gas": 200_000}
                        )
                        safe_wait(w3, coin_tx, "Transfer coin ownership")
                        store_tx = store.functions.transferOwnership(new_admin).transact(
                            {"from": admin_address, "gas": 200_000}
                        )
                        safe_wait(w3, store_tx, "Transfer store ownership")
                        deployments["admin"] = store.functions.getAdmin().call()
                        from admin_helpers import save_deployments  # local import to avoid changing original flow
                        save_deployments(deployments)
                        st.rerun()
                    except Exception as err:
                        st.error(f"Ownership transfer failed: {err}")
