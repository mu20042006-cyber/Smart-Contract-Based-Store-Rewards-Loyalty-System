// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

interface IRewardPointCoin {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}

contract StoreRewards {
    // ── State variables ───────────────────────────────────────────────────────

    struct RewardItem {
        string name;
        uint256 cost;
        uint256 stock;
        bool active;
    }

    uint256 public constant TOKEN_UNIT = 10 ** 18;

    /// @dev Admin address set at construction; only this address may call onlyOwner functions.
    address public admin;

    /// @dev Global pause flag; whenNotPaused blocks all user-facing functions while true.
    bool public paused;

    uint256 public redemptionCount;
    IRewardPointCoin public rewardCoin;

    RewardItem[] private rewardItems;

    mapping(address => string) public userNames;
    mapping(address => bool) public registeredUsers;

    // ── Events ────────────────────────────────────────────────────────────────

    event RewardItemSaved(
        uint256 indexed itemId,
        string name,
        uint256 cost,
        uint256 stock,
        bool active
    );
    event RewardRedeemed(
        address indexed user,
        uint256 indexed itemId,
        string itemName,
        uint256 cost
    );
    event UserRegistered(address indexed user, string name);
    event Paused(address indexed admin);
    event Resumed(address indexed admin);
    event AdminChanged(address indexed oldAdmin, address indexed newAdmin);

    // ── Access-control modifiers ──────────────────────────────────────────────

    /// @notice Restricts a function to the current admin.
    modifier onlyOwner() {
        require(msg.sender == admin, "Only admin can do this");
        _;
    }

    /// @notice Blocks execution when the contract is paused.
    modifier whenNotPaused() {
        require(!paused, "The store is paused");
        _;
    }

    // ── Constructor ───────────────────────────────────────────────────────────

    constructor(address rewardCoinAddress) {
        require(rewardCoinAddress != address(0), "Invalid coin address");
        // The deployer becomes the admin automatically.
        admin = msg.sender;
        rewardCoin = IRewardPointCoin(rewardCoinAddress);
    }

    // ── Admin view ────────────────────────────────────────────────────────────

    /// @notice Returns the current admin address so the terminal can display it.
    function getAdmin() public view returns (address) {
        return admin;
    }

    // ── Reward-item reads (public, no restriction needed) ─────────────────────

    function getRewardItemCount() public view returns (uint256) {
        return rewardItems.length;
    }

    function getRewardItem(uint256 itemId)
        public
        view
        returns (string memory itemName, uint256 cost, uint256 stock, bool active)
    {
        require(itemId < rewardItems.length, "Reward item does not exist");
        RewardItem memory item = rewardItems[itemId];
        return (item.name, item.cost, item.stock, item.active);
    }

    // ── Admin: single item write ──────────────────────────────────────────────

    /// @notice Add a new item (itemId == rewardItems.length) or update an existing one.
    function addOrUpdateRewardItem(
        uint256 itemId,
        string memory itemName,
        uint256 cost,
        uint256 stock,
        bool active
    ) public onlyOwner {
        _saveRewardItem(itemId, itemName, cost, stock, active);
    }

    // ── Admin: batch item write ───────────────────────────────────────────────

    /**
     * @notice Batch-add or batch-update reward items in a single transaction.
     * @dev All arrays must have equal length.  The function loops through every
     *      entry; if any entry is invalid the entire transaction is reverted.
     */
    function batchSaveRewardItems(
        uint256[] memory itemIds,
        string[] memory itemNames,
        uint256[] memory costs,
        uint256[] memory stocks,
        bool[] memory activeStatuses
    ) public onlyOwner {
        // Require all arrays are the same length; reject the whole batch if not.
        require(itemIds.length > 0, "Batch must not be empty");
        require(itemIds.length == itemNames.length, "Item arrays must match");
        require(itemIds.length == costs.length, "Item arrays must match");
        require(itemIds.length == stocks.length, "Item arrays must match");
        require(itemIds.length == activeStatuses.length, "Item arrays must match");

        for (uint256 i = 0; i < itemIds.length; i++) {
            // Per-entry validation: _saveRewardItem contains require checks.
            // Any failure here reverts the entire transaction.
            _saveRewardItem(
                itemIds[i],
                itemNames[i],
                costs[i],
                stocks[i],
                activeStatuses[i]
            );
        }
    }

    // ── User: registration ────────────────────────────────────────────────────

    /**
     * @notice Register a display name on-chain.  Each address may only register once.
     * @dev Protected by whenNotPaused so the admin can halt registrations during maintenance.
     */
    function registerUser(string memory displayName) public whenNotPaused {
        require(!registeredUsers[msg.sender], "User already registered");
        require(bytes(displayName).length > 0, "Name cannot be empty");

        userNames[msg.sender] = displayName;
        registeredUsers[msg.sender] = true;

        emit UserRegistered(msg.sender, displayName);
    }

    // ── User: redeem reward ───────────────────────────────────────────────────

    /**
     * @notice Spend RPC tokens to redeem a reward item.
     * @dev Protected by whenNotPaused; the caller must have pre-approved at least
     *      item.cost * TOKEN_UNIT tokens to this contract.
     */
    function redeemReward(uint256 itemId) public whenNotPaused {
        require(itemId < rewardItems.length, "Reward item does not exist");

        RewardItem storage item = rewardItems[itemId];
        require(item.active, "Reward item is not active");
        require(item.stock > 0, "Reward item is out of stock");

        uint256 paymentAmount = item.cost * TOKEN_UNIT;
        require(
            rewardCoin.transferFrom(msg.sender, admin, paymentAmount),
            "Point payment failed"
        );

        item.stock -= 1;
        redemptionCount += 1;

        emit RewardRedeemed(msg.sender, itemId, item.name, item.cost);
    }

    // ── Admin: pause / resume ─────────────────────────────────────────────────

    function pause() public onlyOwner {
        paused = true;
        emit Paused(msg.sender);
    }

    function resume() public onlyOwner {
        paused = false;
        emit Resumed(msg.sender);
    }

    // ── Admin: ownership transfer ─────────────────────────────────────────────

    /**
     * @notice Transfer admin rights to a new address.
     * @dev Only callable by the current admin (onlyOwner).
     *      After this call the old admin loses all privileges.
     */
    function transferOwnership(address newAdmin) public onlyOwner {
        require(newAdmin != address(0), "Invalid new admin");
        address oldAdmin = admin;
        admin = newAdmin;
        emit AdminChanged(oldAdmin, newAdmin);
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    function _saveRewardItem(
        uint256 itemId,
        string memory itemName,
        uint256 cost,
        uint256 stock,
        bool active
    ) internal {
        // Per-entry requires: if any are violated the whole transaction reverts.
        require(bytes(itemName).length > 0, "Reward name cannot be empty");
        require(cost > 0, "Reward cost must be greater than zero");
        require(itemId <= rewardItems.length, "Invalid reward item id");

        if (itemId == rewardItems.length) {
            rewardItems.push(RewardItem(itemName, cost, stock, active));
        } else {
            rewardItems[itemId] = RewardItem(itemName, cost, stock, active);
        }

        emit RewardItemSaved(itemId, itemName, cost, stock, active);
    }
}
