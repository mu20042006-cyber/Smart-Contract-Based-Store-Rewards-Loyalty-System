// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title RewardPointCoin
 * @notice A minimal ERC-20 token used as the loyalty currency for the Store Rewards system.
 *         Only the admin may mint new tokens.  All standard ERC-20 operations are supported.
 */
contract RewardPointCoin {
    // ── ERC-20 metadata ───────────────────────────────────────────────────────

    string public name = "Reward Point Coin";
    string public symbol = "RPC";
    uint8 public decimals = 18;

    // ── ERC-20 state ──────────────────────────────────────────────────────────

    uint256 public totalSupply;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    // ── Access-control state ──────────────────────────────────────────────────

    /// @dev Set to msg.sender in the constructor; only this address may mint.
    address public admin;

    // ── ERC-20 events ─────────────────────────────────────────────────────────

    /// @dev Emitted on every token movement, including minting (from == address(0)).
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    event AdminChanged(address indexed oldAdmin, address indexed newAdmin);

    // ── Access-control modifier ───────────────────────────────────────────────

    modifier onlyOwner() {
        require(msg.sender == admin, "Only admin can do this");
        _;
    }

    // ── Constructor ───────────────────────────────────────────────────────────

    constructor() {
        // The deployer becomes the admin.
        admin = msg.sender;
    }

    // ── Admin view ────────────────────────────────────────────────────────────

    /// @notice Returns the current admin address (called by the terminal to display who is admin).
    function getAdmin() public view returns (address) {
        return admin;
    }

    // ── Admin: mint ───────────────────────────────────────────────────────────

    /**
     * @notice Create new tokens and assign them to `to`.
     * @dev Restricted to the admin via onlyOwner.
     *      Emits a Transfer event from address(0) as required by ERC-20.
     */
    function mint(address to, uint256 amount) public onlyOwner {
        require(to != address(0), "Cannot mint to zero address");
        require(amount > 0, "Amount must be greater than zero");

        totalSupply += amount;
        balanceOf[to] += amount;

        // ERC-20: minting is represented as a transfer from the zero address.
        emit Transfer(address(0), to, amount);
    }

    // ── ERC-20: transfer ──────────────────────────────────────────────────────

    function transfer(address to, uint256 amount) public returns (bool) {
        _transfer(msg.sender, to, amount);
        return true;
    }

    // ── ERC-20: approve / transferFrom ────────────────────────────────────────

    function approve(address spender, uint256 amount) public returns (bool) {
        require(spender != address(0), "Invalid spender");
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) public returns (bool) {
        require(allowance[from][msg.sender] >= amount, "Not enough allowance");
        allowance[from][msg.sender] -= amount;
        _transfer(from, to, amount);
        return true;
    }

    // ── Admin: ownership transfer ─────────────────────────────────────────────

    /**
     * @notice Transfer admin rights to a new address.
     * @dev Only the current admin may call this (onlyOwner).
     */
    function transferOwnership(address newAdmin) public onlyOwner {
        require(newAdmin != address(0), "Invalid new admin");
        address oldAdmin = admin;
        admin = newAdmin;
        emit AdminChanged(oldAdmin, newAdmin);
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    function _transfer(address from, address to, uint256 amount) internal {
        require(to != address(0), "Cannot transfer to zero address");
        require(balanceOf[from] >= amount, "Not enough coin balance");

        balanceOf[from] -= amount;
        balanceOf[to] += amount;

        emit Transfer(from, to, amount);
    }
}
