"""
terminal_app.py
───────────────
Main command-line interface for the Store Rewards & Points DApp.

Normal user flow:
  1. Choose a Ganache account.
  2. Register a display name if visiting for the first time.
  3. Use the numbered menu to interact with the store.

Hidden admin section:
  Type  admin  at the main menu prompt to open the password-protected
  admin menu (default password: admin123).

Run:
    python user/terminal_app.py
"""

import sys
from pathlib import Path

# Make the admin package importable from the user/ directory.
sys.path.append(str(Path(__file__).resolve().parents[1] / "admin"))

from admin_menu import main as admin_menu
from admin_helpers import connect
from transaction_sender import (
    choose_account,
    ensure_registered,
    get_user_display_name,
    list_reward_items,
    load_app_contracts,
    print_activity_history,
    print_balance_table,
    redeem_reward,
)


# ── Header ────────────────────────────────────────────────────────────────────

def show_header(store, account):
    """Print the menu header showing the user's registered name and wallet."""
    display_name = get_user_display_name(store, account)
    print()
    print("╔══════════════════════════════════╗")
    print("║   Store Rewards & Points DApp    ║")
    print("╚══════════════════════════════════╝")
    # Display the on-chain registered name after registration.
    print(f"  User   : {display_name}")
    print(f"  Wallet : {account}")


# ── Main loop ─────────────────────────────────────────────────────────────────

def main():
    w3 = connect()
    deployments, store, coin = load_app_contracts(w3)

    # ── Account selection ─────────────────────────────────────────────────────
    account = choose_account(w3, deployments["admin"])

    # ── First-visit registration prompt ──────────────────────────────────────
    # ensure_registered checks the on-chain mapping; if the address is not
    # registered it prompts for a name and sends registerUser() on-chain.
    ensure_registered(w3, store, account)

    # ── Main menu loop ────────────────────────────────────────────────────────
    while True:
        show_header(store, account)
        print()
        print("  1.  View reward items")
        print("  2.  Redeem a reward item")
        print("  3.  My activity history")
        print("  4.  Search activity by address")
        print("  5.  Check coin & ETH balance")
        print("  6.  Switch account")
        print("  0.  Exit")
        print()
        print("  (type 'admin' to open the hidden admin menu)")

        choice = input("Choose: ").strip()

        try:
            if choice == "1":
                list_reward_items(store)

            elif choice == "2":
                list_reward_items(store)
                item_id = int(input("  Enter reward item id: ").strip())
                redeem_reward(
                    w3, store, coin, account, item_id,
                    deployments["StoreRewards"],
                )

            elif choice == "3":
                # Show the current user's own activity history.
                print_activity_history(w3, store, coin, account)

            elif choice == "4":
                # Let any user search any address's history.
                address = input("  Address to search: ").strip()
                if not address:
                    print("  No address entered.")
                else:
                    print_activity_history(w3, store, coin, address)

            elif choice == "5":
                # Show coin + ETH balances side by side.
                address = input(
                    "  Address to check (blank = current account): "
                ).strip()
                if not address:
                    address = account
                print_balance_table(w3, coin, address)

            elif choice == "6":
                # Switch to a different Ganache account.
                account = choose_account(w3, deployments["admin"])
                ensure_registered(w3, store, account)

            elif choice == "0":
                print("Goodbye!")
                break

            elif choice.lower() == "admin":
                # ── Hidden admin section ──────────────────────────────────────
                # Password is requested inside admin_menu(); it is not visible
                # on the normal menu, acting as a hidden gate.
                admin_menu()
                # Reload contracts in case admin changed an address or paused.
                deployments, store, coin = load_app_contracts(w3)

            else:
                print("  Unknown option. Please try again.")

        except KeyboardInterrupt:
            print("\nInterrupted.")
            break
        except Exception as error:
            print("  Action failed:", error)


if __name__ == "__main__":
    main()
