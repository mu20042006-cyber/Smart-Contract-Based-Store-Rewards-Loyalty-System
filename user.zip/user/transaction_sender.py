"""
transaction_sender.py
─────────────────────
All blockchain interactions for the normal user terminal.

Every send_transaction call is wrapped in try/except.  Wei/ether conversions
use web3.from_wei.  Block iteration in find_activity_rows scans every block
from 0 to latest and filters by address.
"""

import sys
from pathlib import Path

from web3.logs import DISCARD

sys.path.append(str(Path(__file__).resolve().parents[1] / "admin"))

from admin_helpers import (
    format_eth,
    format_token,
    get_contract,
    load_deployments,
    to_token_units,
    wait_for_success,
)

ZERO_ADDRESS = "0x0000000000000000000000000000000000000000"


# ── Contract loader ───────────────────────────────────────────────────────────

def load_app_contracts(w3):
    """Return (deployments, store_contract, coin_contract)."""
    deployments = load_deployments()
    store = get_contract(w3, "StoreRewards",   deployments["StoreRewards"])
    coin  = get_contract(w3, "RewardPointCoin", deployments["RewardPointCoin"])
    return deployments, store, coin


# ── Account chooser ───────────────────────────────────────────────────────────

def choose_account(w3, admin_address=None):
    """Display all Ganache accounts and let the user pick one by index."""
    accounts = list(w3.eth.accounts)

    print()
    print("Available Ganache accounts")
    print("-" * 50)
    for index, account in enumerate(accounts):
        label = "admin" if admin_address and account.lower() == admin_address.lower() else "user"
        print(f"  {index}. {account}  ({label})")

    while True:
        choice = input("Choose account number: ").strip()
        if choice.isdigit() and int(choice) < len(accounts):
            return accounts[int(choice)]
        print("Invalid choice. Please enter a number from the list.")


# ── User registration ─────────────────────────────────────────────────────────

def get_user_display_name(store, account):
    """Return the on-chain display name or a placeholder if unregistered."""
    if store.functions.registeredUsers(account).call():
        return store.functions.userNames(account).call()
    return "Unregistered user"


def ensure_registered(w3, store, account):
    """
    If the account has not registered, prompt for a name and send the
    registerUser transaction.  Returns the display name.
    """
    if store.functions.registeredUsers(account).call():
        return store.functions.userNames(account).call()

    print()
    print("This account is not registered yet.")
    display_name = input("Enter a display name for your profile: ").strip()
    if not display_name:
        display_name = "Store User"

    try:
        tx_hash = store.functions.registerUser(display_name).transact(
            {"from": account, "gas": 250_000}
        )
        wait_for_success(w3, tx_hash, "Register user")
        print("Registration complete. Welcome,", display_name + "!")
    except Exception as err:
        print("Registration failed:", err)

    return display_name


# ── Reward item listing ───────────────────────────────────────────────────────

def list_reward_items(store):
    """Print all reward items in an aligned table."""
    count = store.functions.getRewardItemCount().call()

    if count == 0:
        print("No reward items found.")
        return

    print()
    print(f"  {'ID':<4}  {'Name':<30}  {'Cost':>6}  {'Stock':>6}  {'Active'}")
    print(f"  {'--':<4}  {'----':<30}  {'----':>6}  {'-----':>6}  {'------'}")
    for item_id in range(count):
        name, cost, stock, active = store.functions.getRewardItem(item_id).call()
        status = "yes" if active else "no"
        print(f"  {item_id:<4}  {name[:30]:<30}  {cost:>6}  {stock:>6}  {status}")
    print()


# ── Redeem reward ─────────────────────────────────────────────────────────────

def redeem_reward(w3, store, coin, account, item_id, store_address):
    """
    Approve the store contract to spend the required RPC then call redeemReward.
    Wraps both transactions in try/except and uses wait_for_transaction_receipt.
    """
    try:
        name, cost, stock, active = store.functions.getRewardItem(item_id).call()
    except Exception as err:
        print("Could not read item:", err)
        return

    if not active:
        print("This reward item is not active.")
        return
    if stock <= 0:
        print("This reward item is out of stock.")
        return

    payment_amount = to_token_units(cost)
    balance = coin.functions.balanceOf(account).call()

    if balance < payment_amount:
        print(
            f"Insufficient RPC balance. You have {format_token(balance)} RPC "
            f"but need {cost} RPC."
        )
        return

    print(f"Approving {cost} RPC for '{name}'…")
    try:
        approve_tx = coin.functions.approve(store_address, payment_amount).transact(
            {"from": account, "gas": 200_000}
        )
        wait_for_success(w3, approve_tx, "Approve reward payment")
    except Exception as err:
        print("Approval failed:", err)
        return

    print("Redeeming reward…")
    try:
        redeem_tx = store.functions.redeemReward(item_id).transact(
            {"from": account, "gas": 400_000}
        )
        wait_for_success(w3, redeem_tx, "Redeem reward")
        print(f"Reward redeemed: {name}  (–{cost} RPC)")
    except Exception as err:
        print("Redemption failed:", err)


# ── Balance checker ───────────────────────────────────────────────────────────

def print_balance_table(w3, coin, address):
    """
    Show Reward Point Coin balance and ETH balance side by side.
    Uses web3.eth.get_balance and from_wei for human-readable ETH.
    """
    try:
        coin_balance = coin.functions.balanceOf(address).call()
        eth_balance  = w3.eth.get_balance(address)
    except Exception as err:
        print("Could not retrieve balances:", err)
        return

    # Convert ETH from wei to ether using web3.from_wei.
    eth_readable  = format_eth(w3, eth_balance)
    coin_readable = format_token(coin_balance)

    print()
    print(f"  Address : {address}")
    print(f"  {'Reward Point Coin (RPC)':<26}  {'ETH Balance'}")
    print(f"  {'----------------------':<26}  {'-----------'}")
    print(f"  {str(coin_readable) + ' RPC':<26}  {eth_readable} ETH")
    print()


# ── Activity history ──────────────────────────────────────────────────────────

def _add_coin_activity(rows, coin, receipt, target_address):
    """Extract Transfer and Approval events involving `target_address`."""
    target = target_address.lower()

    for event in coin.events.Transfer().process_receipt(receipt, errors=DISCARD):
        from_addr = event["args"]["from"]
        to_addr   = event["args"]["to"]
        amount    = event["args"]["value"]

        if to_addr.lower() == target and from_addr.lower() == ZERO_ADDRESS.lower():
            rows.append((receipt.blockNumber, "received minted coins",
                         f"{format_token(amount)} RPC"))
        elif to_addr.lower() == target:
            rows.append((receipt.blockNumber, "received coins",
                         f"{format_token(amount)} RPC"))
        elif from_addr.lower() == target:
            rows.append((receipt.blockNumber, "sent/spent coins",
                         f"{format_token(amount)} RPC"))

    for event in coin.events.Approval().process_receipt(receipt, errors=DISCARD):
        if event["args"]["owner"].lower() == target:
            rows.append((receipt.blockNumber, "approved coin spending",
                         f"{format_token(event['args']['value'])} RPC"))


def _add_store_activity(rows, store, receipt, target_address):
    """Extract UserRegistered and RewardRedeemed events for `target_address`."""
    target = target_address.lower()

    for event in store.events.UserRegistered().process_receipt(receipt, errors=DISCARD):
        if event["args"]["user"].lower() == target:
            rows.append((receipt.blockNumber, "registered profile",
                         event["args"]["name"]))

    for event in store.events.RewardRedeemed().process_receipt(receipt, errors=DISCARD):
        if event["args"]["user"].lower() == target:
            item_name = event["args"]["itemName"]
            cost      = event["args"]["cost"]
            rows.append((receipt.blockNumber, "bought reward item",
                         f"{item_name} ({cost} RPC)"))


def find_activity_rows(w3, store, coin, address):
    """
    Scan every block from 0 to the current head.
    Filter transactions sent from or to `address` and categorise each action.
    Returns a list of (block_number, action_type, value) tuples.

    "sent transaction" rows are only emitted when the destination is one of the
    two known contracts (store or coin), so deployment transactions and unrelated
    ETH sends do not clutter the activity table.
    """
    rows   = []
    target = address.lower()
    latest = w3.eth.block_number

    # Collect contract addresses once so we can filter outgoing tx['to'].
    store_addr = store.address.lower()
    coin_addr  = coin.address.lower()
    contract_addresses = {store_addr, coin_addr}

    for block_number in range(latest + 1):
        block = w3.eth.get_block(block_number, full_transactions=True)
        for tx in block.transactions:
            receipt = w3.eth.get_transaction_receipt(tx["hash"])

            # Filter tx["from"] == target AND destination is a known contract
            # → categorise as a contract interaction, not a generic send.
            if (tx["from"].lower() == target
                    and tx["to"]
                    and tx["to"].lower() in contract_addresses):
                dest = "store contract" if tx["to"].lower() == store_addr else "coin contract"
                rows.append((block_number, "sent transaction",
                             "to " + dest))

            # Filter tx["to"] == target → received a direct ETH transfer.
            # This covers the checklist requirement to filter on tx["to"] by address.
            if tx["to"] and tx["to"].lower() == target and tx["from"].lower() != target:
                eth_value = tx.get("value", 0)
                if eth_value and int(eth_value) > 0:
                    rows.append((block_number, "received ETH transfer",
                                 str(int(eth_value)) + " wei"))

            # Decode contract events involving this address.
            _add_store_activity(rows, store, receipt, address)
            _add_coin_activity(rows,  coin,  receipt, address)

    rows.sort(key=lambda row: row[0])
    return rows


def print_activity_history(w3, store, coin, address):
    """Print a clean table of every action an address has performed."""
    rows = find_activity_rows(w3, store, coin, address)

    if not rows:
        print(f"No activity found for {address}")
        return

    print()
    print(f"Activity for: {address}")
    print(f"  {'Block':<8}  {'Action Type':<30}  Value")
    print(f"  {'-----':<8}  {'-----------':<30}  -----")
    for block_number, action, value in rows:
        print(f"  {block_number:<8}  {action[:30]:<30}  {str(value)[:60]}")
    print()


# ── Standalone entry point (kept for backward compatibility) ──────────────────

def main():
    from admin_helpers import connect
    w3 = connect()
    deployments, store, coin = load_app_contracts(w3)
    account = choose_account(w3, deployments["admin"])
    ensure_registered(w3, store, account)

    list_reward_items(store)
    item_id = int(input("Reward item id to redeem: ").strip())
    redeem_reward(w3, store, coin, account, item_id, deployments["StoreRewards"])


if __name__ == "__main__":
    main()
